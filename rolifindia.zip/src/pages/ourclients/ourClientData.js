import Img1 from '../../assets/images/clients/acegroup.png'
import Img2 from '../../assets/images/clients/awfis.jpg'
import Img3 from '../../assets/images/clients/bmr.png'
import Img4 from '../../assets/images/clients/cisf.jpg'
import Img5 from '../../assets/images/clients/csc.png'
import Img6 from '../../assets/images/clients/denz.jpg'
import Img7 from '../../assets/images/clients/icici.png'
import Img8 from '../../assets/images/clients/intex.png'
import Img9 from '../../assets/images/clients/kailash.png'
import Img10 from '../../assets/images/clients/kfc.png'
import Img12 from '../../assets/images/clients/lufthansa.png'
import Img13 from '../../assets/images/clients/macqurie.png'
import Img14 from '../../assets/images/clients/max healthcare.png'
import Img15 from '../../assets/images/clients/modiinfosol.png'
import Img16 from '../../assets/images/clients/moolchand.jpg'
import Img17 from '../../assets/images/clients/naukary.png'
import Img18 from '../../assets/images/clients/new delhi.jpg'
import Img19 from '../../assets/images/clients/ntpc.png'
import Img20 from '../../assets/images/clients/orthonova.png'
import Img21 from '../../assets/images/clients/samco.jpg'
import Img22 from '../../assets/images/clients/supperteck.jpg'
import Img23 from '../../assets/images/clients/systra.png'
import Img24 from '../../assets/images/clients/telenor.png'
import Img25 from '../../assets/images/clients/timex.png'
import Img26 from '../../assets/images/clients/vatika.jpg'
import Img27 from '../../assets/images/clients/venketeswar.jpg'
import Img28 from '../../assets/images/clients/yashoda.png'

export const ourClientData1 = [
    { id: 1, image: Img1, },
    { id: 2, image: Img2, },
    { id: 3, image: Img3, },
    { id: 4, image: Img4, },
    { id: 5, image: Img5, },
    { id: 6, image: Img6, },
    { id: 7, image: Img7, },
    { id: 8, image: Img8, },
    { id: 9, image: Img9, },
];
export const ourClientData2 = [
    { id: 10, image: Img10, },
    { id: 12, image: Img12, },
    { id: 13, image: Img13, },
    { id: 14, image: Img14, },
    { id: 15, image: Img15, },
    { id: 16, image: Img16, },
    { id: 17, image: Img17, },
    { id: 18, image: Img18, },
];
export const ourClientData3 = [
    { id: 19, image: Img19, },
    { id: 20, image: Img20, },
    { id: 21, image: Img21, },
    { id: 22, image: Img22, },
    { id: 23, image: Img23, },
    { id: 24, image: Img24, },
    { id: 25, image: Img25, },
    { id: 26, image: Img26, },
    { id: 27, image: Img27, },
    { id: 28, image: Img28, },
]