import { Box, Divider, Typography, useTheme } from '@mui/material';
import Banner from '../../utils/Banner';
import Civil2 from '../../assets/images/civil/civil2.webp';
import { civilData, } from './mainPageData';
import ProjectSection from './ProjectSection';

const Civilconstruction = () => {
    const theme = useTheme();

    return (
        <>
            {/* Page Banner */}
            <Banner
                title="Civil Construction Projects"
                image={Civil2}
                height={{ sm: '35vh', md: '45vh', xs: '40vh', lg: '55vh', xl: '50vh' }}
                titleVariant="h2"
                overlayColor="rgba(30,57,81,0.2)"
                spacingConfig={{ xl: 12, lg: 12, md: 2, xs: 1 }}
                containerStyles={{ overflow: "hidden" }}
                text="Civil Constructions"
            />

            {/* Main Content */}
            <Box sx={{ py: 6, px: { lg: 12, md: 2, sm: 2, xs: 2 }, background: '#f1f1f1' }}>
                {/* Title Section */}
                <Box sx={{ py: 2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Typography variant="h4" fontWeight={'bold'}>
                        Civil{' '}
                        <Typography component={'span'} variant="h4" fontWeight="bold" color="primary.main" py={2}>
                            Construction Projects
                        </Typography>
                        <Divider sx={{ background: theme.palette.primary.deep, height: '3px', width: '50px' }} />
                    </Typography>
                </Box>

                {/* Dynamically Render Sections */}
                {civilData.map((item) => (
                    <ProjectSection
                        key={item.id}
                        title={item.title}
                        description={[item.description[0], item.description[1]]}
                        image={item.imagePath}
                    />
                ))}
            </Box>
        </>
    );
};

export default Civilconstruction;
