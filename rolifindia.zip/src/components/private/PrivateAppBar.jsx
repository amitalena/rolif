import { Box, Typography } from "@mui/material"

const PrivateAppBar = () => {
    return (
        <>
            <Box>
                <Typography>This is admin AppBar</Typography>
            </Box>
        </>
    )
}

export default PrivateAppBar